<?php $__env->startSection('content'); ?>
    <div class="container">
        <span>Your not in this room. Join first to access room content. Ask room owner for code. Then click button bellow</span>
        <a class="btn btn-success" href="<?php echo e(route('room.join', $room->id)); ?>">Join room</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/room/joinFirst.blade.php ENDPATH**/ ?>