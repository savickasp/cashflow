<?php $__env->startSection('content'); ?>
    <div class="container">
        <span>Sorry, but your not admin of this room....</span>
        <a class="btn btn-success" href="<?php echo e(route(back())); ?>">Return to previous page</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/room/notAdmin.blade.php ENDPATH**/ ?>