<?php $__env->startSection('content'); ?>
    <div class="container">
        <table>
            <thead>
            <tr>
                <td>Room name</td>
                <td>Owner</td>
                <td>Created at</td>
                <td>Actions</td>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('room.show', $room->room_id)); ?>"><?php echo e($room->name); ?></a></td>
                <td><a href="<?php echo e(route('user.profile', $room->owner_id)); ?>"><?php echo e($room->username); ?></a></td>
                <td><?php echo e($room->created_at); ?></td>
                <td>
                    <a class="btn btn-success"
                        href="<?php echo e(route('room.show', $room->room_id)); ?>">enter</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/room/index.blade.php ENDPATH**/ ?>