<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="post">
            <?php echo csrf_field(); ?>
            <input name="string" type="hidden" value="<?php echo e($string); ?>">
            <div class="form-group">
                <label>Repeat this to confirm delete: <b><?php echo e($string); ?></b></label>
                <input name="string_confirm" type="text" class="form-control" placeholder="confirm delete">
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <button type="submit" class="btn btn-danger">delete</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/room/destroy.blade.php ENDPATH**/ ?>