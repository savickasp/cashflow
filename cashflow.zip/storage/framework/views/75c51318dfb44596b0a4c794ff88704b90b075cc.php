<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-between">
        <table>
            <thead>
            <tr>
                <td>Player</td>
                <td>Specialty</td>
                <td>Actions</td>
                <?php if($room->owner_id === auth()->user()->id): ?>
                    <td>
                        Admin actions
                    </td>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($player->username); ?></td>
                    <td>
                        <?php if($player->player_role): ?>
                            <?php echo e($player->player_role); ?>

                        <?php elseif($player->user_id === auth()->user()->id): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('game.role', $player->id)); ?>">set role</a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($player->player_role === null): ?>
                            <span>Set Role first</span>
                        <?php else: ?>
                            <?php if($player->user_id === auth()->user()->id): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('game.index', $player->id)); ?>">game sheet</a>
                            <?php else: ?>
                                <a class="btn btn-primary" href="<?php echo e(route('game.check', $player->id)); ?>">check
                                    player</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <?php if($room->owner_id === auth()->user()->id && $player->user_id !== auth()->user()->id): ?>
                        <td>
                            <a class="btn btn-primary"
                               href="<?php echo e(route('room.setAdmin', ['room' => $room->id, 'user' => $player->user_id])); ?>">Make
                                admin</a>
                            <a class="btn btn-danger"
                               href="<?php echo e(route('room.kick', ['room' => $room->id, 'user' => $player->user_id])); ?>">kick
                                player</a>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div>
            <a class="btn btn-secondary" href="<?php echo e(route('room.edit', $room->id)); ?>">Room settings</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/room/show.blade.php ENDPATH**/ ?>