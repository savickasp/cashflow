<?php $__env->startSection('content'); ?>
    <div class="container" id="app">
        <game-sheet :user='<?php echo json_encode($user, 15, 512) ?>' :translation='<?php echo json_encode($translation, 15, 512) ?>'></game-sheet>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/game/index.blade.php ENDPATH**/ ?>