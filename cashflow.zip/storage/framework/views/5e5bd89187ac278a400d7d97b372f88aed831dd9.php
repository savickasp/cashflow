<?php $__env->startSection('content'); ?>
    <div class="container">
        <span>Sorry, but your not admin of this room....</span>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\cashflow\resources\views/room/notOwner.blade.php ENDPATH**/ ?>