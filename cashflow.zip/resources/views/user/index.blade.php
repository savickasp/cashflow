@extends('layouts.app')

@section('content')
    <div class="container">
        user.index
    </div>
@endsection
