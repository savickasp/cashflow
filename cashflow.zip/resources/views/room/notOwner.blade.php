@extends('layouts.app')

@section('content')
    <div class="container">
        <span>Sorry, but your not admin of this room....</span>
    </div>
@endsection
