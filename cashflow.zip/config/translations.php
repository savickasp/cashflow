<?php

return [
    'salary' => 'Atlyginimas',
    'taxes' => 'Mokesčiai',
    'flat_payment' => 'Būsto paskolos įmoka',
    'study_payment' => 'Studijų paskolos įmoka',
    'car_payment' => 'Mšinos paskolos įmoka',
    'credit_payment' => 'Kredito paskolos įmoka',
    'consumer_payment' => 'Vartojamo paskolos įmoka',
    'other_expenses' => 'Kitos išlaidos',
    'child_expenses' => 'Vaiko išlaidos',
    'flat_loan' => 'Būsto paskola',
    'study_loan' => 'Studijų paskola',
    'car_loan' => 'Mašinos paskola',
    'credit_loan' => 'Kredito paskola',
    'consumer_loan' => 'Vartojimo paskola',
    'bank_loan' => 'Banko paskola',
    'cash' => 'Turimi pinigai',
];
